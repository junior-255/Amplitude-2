#pragma once
#include <cmath>
#include <complex>
#include <vector>
#include <algorithm>
#include <atomic>
typedef std::complex<double> cpx;
static inline double dB2l(double d) { return std::pow(10.0, d / 20.0); }
static inline double l2dB(double l) { return 20.0 * std::log10(std::max(l, 1e-12)); }

struct FFT {  // radix-2, double precision (up to 65536 points)
    int n = 0; std::vector<int> rev; std::vector<cpx> tw;
    void init(int N) {
        n = N; int lg = 0; while ((1 << lg) < N) lg++;
        rev.assign(N, 0); for (int i = 1; i < N; i++) rev[i] = (rev[i >> 1] >> 1) | ((i & 1) << (lg - 1));
        tw.resize(N / 2); for (int i = 0; i < N / 2; i++) tw[i] = std::polar(1.0, -2 * M_PI * i / N);
    }
    void run(cpx* a, bool inv) {
        for (int i = 0; i < n; i++) if (i < rev[i]) std::swap(a[i], a[rev[i]]);
        for (int len = 2; len <= n; len <<= 1) {
            int half = len / 2, step = n / len;
            for (int i = 0; i < n; i += len) for (int j = 0; j < half; j++) {
                cpx w = inv ? std::conj(tw[j * step]) : tw[j * step];
                cpx u = a[i + j], v = a[i + j + half] * w; a[i + j] = u + v; a[i + j + half] = u - v;
            }
        }
        if (inv) for (int i = 0; i < n; i++) a[i] /= (double)n;
    }
};

struct Biq {  // RBJ biquad; types: 1 peak, 2 low shelf, 3 high shelf, 4 HP, 5 LP, 6 notch, 7 band-pass
    double b0=1,b1=0,b2=0,a1=0,a2=0,z1=0,z2=0;
    void set(double B0,double B1,double B2,double A0,double A1,double A2){ b0=B0/A0;b1=B1/A0;b2=B2/A0;a1=A1/A0;a2=A2/A0; }
    void rbj(int t, double f, double g, double q, double fs) {
        double w=2*M_PI*f/fs, c=cos(w), s=sin(w), al=s/(2*q), A=std::pow(10.0,g/40), sA=2*std::sqrt(A)*al;
        switch (t) {
            case 1: set(1+al*A,-2*c,1-al*A,1+al/A,-2*c,1-al/A); break;
            case 2: set(A*((A+1)-(A-1)*c+sA),2*A*((A-1)-(A+1)*c),A*((A+1)-(A-1)*c-sA),(A+1)+(A-1)*c+sA,-2*((A-1)+(A+1)*c),(A+1)+(A-1)*c-sA); break;
            case 3: set(A*((A+1)+(A-1)*c+sA),-2*A*((A-1)+(A+1)*c),A*((A+1)+(A-1)*c-sA),(A+1)-(A-1)*c+sA,2*((A-1)-(A+1)*c),(A+1)-(A-1)*c-sA); break;
            case 4: set((1+c)/2,-(1+c),(1+c)/2,1+al,-2*c,1-al); break;
            case 5: set((1-c)/2,1-c,(1-c)/2,1+al,-2*c,1-al); break;
            case 6: set(1,-2*c,1,1+al,-2*c,1-al); break;
            case 7: set(al,0,-al,1+al,-2*c,1-al); break;
        }
    }
    double p(double x) { double y=b0*x+z1; z1=b1*x-a1*y+z2; z2=b2*x-a2*y; return y; }
    double mag(double f, double fs) const {
        double w=2*M_PI*f/fs; cpx e1=std::polar(1.0,-w), e2=std::polar(1.0,-2*w);
        return std::abs((b0+b1*e1+b2*e2)/(1.0+a1*e1+a2*e2));
    }
};

struct Oversampler {
    int n = 4; Biq up[2], dn[2];
    void init(int factor, double fs) {
        n = factor; double fo = fs * n;
        for (auto* s : {up, dn}) { s[0] = Biq(); s[1] = Biq(); s[0].rbj(5, 0.45*fs, 0, 0.54, fo); s[1].rbj(5, 0.45*fs, 0, 1.31, fo); }
    }
    template<class F> double run(double x, F f) {
        double out = 0;
        for (int i = 0; i < n; i++) {
            double u = up[1].p(up[0].p(i == 0 ? x * n : 0.0));
            double y = dn[1].p(dn[0].p(f(u)));
            if (i == 0) out = y;
        }
        return out;
    }
};

struct Conv {  // uniform-partition FFT overlap-add convolver; latency = B samples (+ kernel delay)
    int B = 1024, F = 0, pos = 0; bool ready = false;
    FFT fft; std::vector<cpx> K, buf; std::vector<double> in, ov, out;
    void setKernel(const std::vector<double>& h) {
        int nF = 1; while (nF < B + (int)h.size() - 1) nF <<= 1;
        if (nF != F) { F = nF; fft.init(F); buf.assign(F, 0); ov.assign(F, 0); in.assign(B, 0); out.assign(B, 0); pos = 0; }
        K.assign(F, 0); for (size_t i = 0; i < h.size(); i++) K[i] = h[i];
        fft.run(K.data(), false); ready = true;
    }
    double tick(double x) {
        if (!ready) return x;
        in[pos] = x; double y = out[pos];
        if (++pos == B) {
            for (int i = 0; i < B; i++) buf[i] = in[i];
            for (int i = B; i < F; i++) buf[i] = 0;
            fft.run(buf.data(), false);
            for (int i = 0; i < F; i++) buf[i] *= K[i];
            fft.run(buf.data(), true);
            for (int i = 0; i < F; i++) ov[i] += buf[i].real();
            for (int i = 0; i < B; i++) out[i] = ov[i];
            std::copy(ov.begin() + B, ov.end(), ov.begin()); std::fill(ov.end() - B, ov.end(), 0.0);
            pos = 0;
        }
        return y;
    }
};

struct Lufs {  // ITU-R BS.1770 K-weighting, momentary (400 ms), short-term (3 s), integrated (gated)
    Biq a[2], b[2]; int blk = 4800, cnt = 0, rp = 0, nblk = 0; double acc = 0;
    std::vector<double> r, hist; double M = -120, S = -120, I = -120;
    static double pw(double p) { return -0.691 + 10 * std::log10(std::max(p, 1e-12)); }
    void init(double fs) {
        double f0 = 1681.974450955533, G = 3.999843853973347, Q = 0.7071752369554196;
        double K = std::tan(M_PI * f0 / fs), Vh = std::pow(10.0, G / 20), Vb = std::pow(Vh, 0.4996667741545416), a0 = 1 + K/Q + K*K;
        Biq s1; s1.set(Vh + Vb*K/Q + K*K, 2*(K*K - Vh), Vh - Vb*K/Q + K*K, a0, 2*(K*K - 1), 1 - K/Q + K*K);
        f0 = 38.13547087602444; Q = 0.5003270373238773; K = std::tan(M_PI * f0 / fs); a0 = 1 + K/Q + K*K;
        Biq s2; s2.set(a0, -2*a0, a0, a0, 2*(K*K - 1), 1 - K/Q + K*K);
        a[0] = a[1] = s1; b[0] = b[1] = s2;
        blk = (int)(fs * 0.1); cnt = 0; rp = 0; nblk = 0; acc = 0; r.assign(30, 0); hist.clear(); M = S = I = -120;
    }
    bool push(double l, double rr) {
        double zl = b[0].p(a[0].p(l)), zr = b[1].p(a[1].p(rr)); acc += zl*zl + zr*zr;
        if (++cnt < blk) return false;
        r[rp] = acc / cnt; rp = (rp + 1) % 30; nblk++; cnt = 0; acc = 0;
        if (nblk >= 4) {
            double m = 0; for (int i = 1; i <= 4; i++) m += r[(rp - i + 30) % 30]; m /= 4; M = pw(m); hist.push_back(m);
            double sum = 0, n = 0; for (double h : hist) if (pw(h) > -70) { sum += h; n++; }
            if (n > 0) { double rel = pw(sum / n) - 10, s2 = 0, n2 = 0; for (double h : hist) if (pw(h) > rel) { s2 += h; n2++; } if (n2 > 0) I = pw(s2 / n2); }
        }
        if (nblk >= 30) { double s = 0; for (double v : r) s += v; S = pw(s / 30); }
        return true;
    }
};

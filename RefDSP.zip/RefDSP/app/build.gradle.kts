plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.refdsp"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.refdsp"; minSdk = 26; targetSdk = 34; versionCode = 1; versionName = "0.1"
        externalNativeBuild { cmake { cppFlags += "-std=c++17 -O3 -ffast-math" } }
        ndk { abiFilters += listOf("arm64-v8a", "x86_64") }
    }
    externalNativeBuild { cmake { path = file("src/main/cpp/CMakeLists.txt") } }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}

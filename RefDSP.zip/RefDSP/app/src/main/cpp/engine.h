#pragma once
#include "dsp.h"
// Chain: [IR conv] -> Parametric EQ (analog sat) -> Saturation -> Compressor -> RMS Limiter -> Translation -> True Peak Limiter
enum P { SAT_ON, SAT_MODE, DRIVE, MIX, HARM, OUT_TRIM, OS,
         COMP_ON, C_THR, C_RATIO, C_ATK, C_REL, C_KNEE, C_MAKEUP, C_RMS,
         RL_ON, RL_THR, RL_RATIO, RL_WIN, RL_ATK, RL_REL, TP_ON, TP_CEIL, TP_REL,
         EQ_ON, EQ_LIN, EQ_ANALOG, TR_PROF, TR_AMT, TR_BASS, TR_LOUD, TR_TGT, FFT_LOG, IR_ON,
         EQ0 = 36, NP = 76 };  // EQ band b: EQ0+b*5 + {type,freq,gain,Q,sat}

struct TB { int t; double f, g, q; };  // starting-point curves, NOT measured calibrations
static const TB PROF[7][3] = {
    {{0,0,0,0},{0,0,0,0},{0,0,0,0}},                          // 0 off
    {{0,0,0,0},{0,0,0,0},{0,0,0,0}},                          // 1 studio monitors (flat reference)
    {{2,100,2,.7},{1,3000,1,1},{3,8000,-1,.7}},               // 2 headphones
    {{2,100,2.5,.7},{1,3000,-1.5,1},{3,9000,-1.5,.7}},        // 3 IEM
    {{4,70,0,.7},{1,2500,2,.8},{3,9000,1.5,.7}},              // 4 Bluetooth speaker
    {{2,80,3,.7},{1,400,-1.5,.8},{3,8000,2,.7}},              // 5 car audio
    {{2,100,1.5,.7},{0,0,0,0},{3,8000,1.5,.7}} };             // 6 consumer

struct Engine {
    static constexpr int NB = 8, B = 1024, LN = 4096, LC = 2048, LM = 8192, D = B + LC;
    double fs = 48000; float p[NP]; float cache[41]; float trc[2] = {-1, -1};
    bool linBuilt = false, irReady = false;
    Oversampler os[2]; int curOs = 0;
    double dcx[2]={0,0}, dcy[2]={0,0}, edx[2]={0,0}, edy[2]={0,0};
    double cGR=0, rmsC=0, rlMs=0, rlGR=0, trG=1, trT=1, cLR=0, cLL=0, cRR=0;
    Biq eq[2][NB], bp[2][NB], tr[2][3], bl, bh1, bh2;
    bool act[NB]; double bw[NB], kd[NB];
    Conv lin[2], ir[2]; FFT dfft; std::vector<double> hd[2]; int hp = 0;
    std::vector<double> pendIR; std::atomic<int> irPend{0};
    Lufs lPre, lOut;
    std::vector<double> dl[2], tg, gs; int la = 72, w = 0; double gSm = 1;
    std::vector<double> ar; int ap = 0; float sc[512]; int sp = 0; FFT afft; std::vector<cpx> ab;
    std::atomic<float> mv[8]; std::atomic<int> lufsReset{0};

    Engine() {
        std::fill(p, p + NP, 0.f);
        const float d[34] = {1,3,6,1,.5f,0,2, 1,-18,2.5f,10,120,6,0,0, 1,-14,8,300,20,300, 1,-1,150, 1,0,.5f,0,1,0,0,-14,13,0};
        std::copy(d, d + 34, p);
        const int ty[8] = {2,1,1,1,1,1,1,3}; const float fr[8] = {50,150,400,1000,2500,6000,10000,14000};
        for (int b = 0; b < NB; b++) { float* q = p + EQ0 + b*5; q[0]=ty[b]; q[1]=fr[b]; q[2]=0; q[3]=(b==0||b==7)?.7f:1.f; q[4]=.5f; }
        for (auto& m : mv) m = 0; std::fill(cache, cache + 41, -9999.f); std::fill(sc, sc + 512, 0.f);
    }
    void init(double sr) {
        fs = sr; la = std::max(8, (int)(0.0015 * fs));
        for (auto& v : dl) v.assign(la + 4, 0.0);
        for (auto& v : hd) v.assign(D, 0.0); hp = 0;
        tg.assign(la + 4, 1.0); gs.assign(la + 4, 1.0); w = 0; gSm = 1; curOs = 0;
        lPre.init(fs); lOut.init(fs); ar.assign(65536, 0.0); ap = 0;
        for (int c = 0; c < 2; c++) { lin[c] = Conv(); ir[c] = Conv(); for (int b = 0; b < NB; b++) { eq[c][b] = Biq(); bp[c][b] = Biq(); } for (auto& t : tr[c]) t = Biq(); }
        bl = Biq(); bh1 = Biq(); bh2 = Biq(); bl.rbj(5,120,0,.7,fs); bh1.rbj(4,130,0,.7,fs); bh2.rbj(5,800,0,.7,fs);
        dfft.init(LM); std::fill(cache, cache + 41, -9999.f); trc[0] = trc[1] = -1; linBuilt = false; irReady = false; irPend = 0;
        cGR = rmsC = rlMs = rlGR = 0; trG = trT = 1;
    }
    void setIR(const float* d, int n) {
        std::vector<double> h(n); double e = 0; for (int i = 0; i < n; i++) { h[i] = d[i]; e += h[i]*h[i]; }
        double s = e > 0 ? 1.0 / std::sqrt(e) : 1.0; for (auto& v : h) v *= s;
        pendIR = h; irPend = 1;
    }
    int latency() const { return (p[TP_ON] > .5 ? la : 0) + (p[EQ_ON] > .5 && p[EQ_LIN] > .5 ? D : 0) + (p[IR_ON] > .5 && irReady ? B : 0); }

    static double shape(int m, double x, double h) {
        switch (m) {
            case 0: return std::tanh(x);
            case 1: return std::tanh(0.8 * x) / 0.8 * 0.9;
            case 2: return std::tanh(x + 0.3) - std::tanh(0.3);
            case 3: return x + h * (x * x - 0.5);
            case 4: return x - h * x * x * x / 3.0;
            default: return 0.5 * (std::tanh(x + 0.3) - std::tanh(0.3)) + 0.5 * (x - h * x * x * x / 3.0);
        }
    }
    static double isp(const double* s) {
        double m = std::max(std::fabs(s[1]), std::fabs(s[2]));
        for (double t : {0.25, 0.5, 0.75}) {
            double v = 0.5*((2*s[1]) + (-s[0]+s[2])*t + (2*s[0]-5*s[1]+4*s[2]-s[3])*t*t + (-s[0]+3*s[1]-3*s[2]+s[3])*t*t*t);
            m = std::max(m, std::fabs(v));
        }
        return m;
    }
    void updateEq() {
        float cur[41]; for (int i = 0; i < 40; i++) cur[i] = p[EQ0 + i]; cur[40] = p[EQ_ANALOG];
        bool ch = false; for (int i = 0; i < 41; i++) if (cur[i] != cache[i]) ch = true;
        if (!ch) return; std::copy(cur, cur + 41, cache);
        for (int b = 0; b < NB; b++) {
            int t = (int)cur[b*5]; double f = std::clamp((double)cur[b*5+1], 10.0, 0.45*fs), g = cur[b*5+2];
            double q = std::clamp((double)cur[b*5+3], 0.1, 50.0), s = cur[b*5+4];
            act[b] = (t >= 4 && t <= 6) || (t >= 1 && t <= 3 && std::fabs(g) > 0.01);
            bool sh = t >= 1 && t <= 3;
            bw[b] = sh ? s * cur[40] * std::clamp(0.35 + g / 9.0, 0.0, 2.5) : 0.0;  // frequency-dependent analog saturation weight
            kd[b] = 2.0 + 0.5 * std::max(g, 0.0);                                    // boosted bands are driven harder
            for (int c = 0; c < 2; c++) {
                if (t >= 1 && t <= 6) eq[c][b].rbj(t, f, g, q, fs);
                if (sh) bp[c][b].rbj(7, f, 0, t == 1 ? std::clamp(q, 0.3, 10.0) : 0.7, fs);
            }
        }
        linBuilt = false;
    }
    void designLin() {  // frequency-sampling FIR from the EQ magnitude, zero-phase -> centered, Hann-windowed
        std::vector<cpx> H(LM);
        for (int k = 0; k <= LM/2; k++) { double f = std::max(k * fs / LM, 0.01), m = 1; for (int b = 0; b < NB; b++) if (act[b]) m *= eq[0][b].mag(f, fs); H[k] = m; }
        for (int k = 1; k < LM/2; k++) H[LM - k] = H[k];
        dfft.run(H.data(), true);
        std::vector<double> h(LN);
        for (int j = 0; j < LN; j++) h[j] = H[(j - LC + LM) % LM].real() * (0.5 - 0.5 * std::cos(2*M_PI*j/(LN-1)));
        lin[0].setKernel(h); lin[1].setKernel(h); linBuilt = true;
    }
    void updateTr() {
        if (p[TR_PROF] == trc[0] && p[TR_AMT] == trc[1]) return; trc[0] = p[TR_PROF]; trc[1] = p[TR_AMT];
        int pi = std::clamp((int)p[TR_PROF], 0, 6);
        for (int c = 0; c < 2; c++) for (int i = 0; i < 3; i++) if (PROF[pi][i].t) tr[c][i].rbj(PROF[pi][i].t, PROF[pi][i].f, PROF[pi][i].g * p[TR_AMT], PROF[pi][i].q, fs);
    }

    void process(float* io, int frames) {
        if (lufsReset.exchange(0)) { lPre.init(fs); lOut.init(fs); }
        if (irPend.exchange(0)) { ir[0].setKernel(pendIR); ir[1].setKernel(pendIR); irReady = true; }
        updateEq(); bool lm = p[EQ_LIN] > .5; if (lm && !linBuilt) designLin(); updateTr();
        int osN = 1 << (int)std::clamp(p[OS], 0.f, 4.f);
        if (osN != curOs) { curOs = osN; for (auto& o : os) o.init(osN, fs); }
        double drive = dB2l(p[DRIVE]), mix = p[MIX], h = p[HARM], trim = dB2l(p[OUT_TRIM]); int mode = (int)p[SAT_MODE];
        double ca = std::exp(-1.0 / (0.001 * std::max(0.1f, p[C_ATK]) * fs)), cr = std::exp(-1.0 / (0.001 * p[C_REL] * fs));
        double ra = std::exp(-1.0 / (0.001 * p[RL_ATK] * fs)), rr = std::exp(-1.0 / (0.001 * p[RL_REL] * fs));
        double rw = std::exp(-1.0 / (0.001 * p[RL_WIN] * fs)), rc = std::exp(-1.0 / (0.01 * fs));
        double tr_ = std::exp(-1.0 / (0.001 * p[TP_REL] * fs)), ceil = dB2l(p[TP_CEIL]);
        double trA = 1 - std::exp(-1.0 / (0.3 * fs)), cA = 1 - std::exp(-1.0 / (0.3 * fs));
        const double t15 = std::tanh(0.15), l15 = 1 - t15 * t15;
        double pk = 0, sq = 0, gr = 0;
        for (int i = 0; i < frames; i++) {
            double x[2] = { io[2*i], io[2*i+1] };
            if (p[IR_ON] > .5 && irReady) for (int c = 0; c < 2; c++) x[c] = ir[c].tick(x[c]);
            if (p[EQ_ON] > .5) {
                for (int c = 0; c < 2; c++) {
                    double raw = x[c], hs = 0;
                    for (int b = 0; b < NB; b++) if (bw[b] > 1e-4) {   // saturate only the energy inside each band
                        double u = bp[c][b].p(raw) * kd[b];
                        hs += bw[b] * ((std::tanh(u + 0.15) - t15) - u * l15) / kd[b];
                    }
                    double hdc = hs - edx[c] + 0.9995 * edy[c]; edx[c] = hs; edy[c] = hdc; hs = hdc;
                    double y;
                    if (lm) { y = lin[c].tick(raw); double dd = hd[c][hp]; hd[c][hp] = hs; hs = dd; }
                    else { y = raw; for (int b = 0; b < NB; b++) if (act[b]) y = eq[c][b].p(y); }
                    x[c] = y + hs;
                }
                if (lm) hp = (hp + 1) % D;
            }
            if (p[SAT_ON] > .5) {
                if (mode == 1) { double l = x[0], r = x[1]; x[0] = l + 0.01*r; x[1] = r + 0.01*l; }
                for (int c = 0; c < 2; c++) {
                    double dry = x[c];
                    double wet = os[c].run(dry * drive, [&](double u){ return shape(mode, u, h); });
                    double y = wet - dcx[c] + 0.9995 * dcy[c]; dcx[c] = wet; dcy[c] = y;
                    x[c] = (dry * (1 - mix) + (y / std::sqrt(drive)) * mix) * trim;
                }
            }
            if (p[COMP_ON] > .5) {
                double lv;
                if (p[C_RMS] > .5) { rmsC = rc*rmsC + (1-rc)*0.5*(x[0]*x[0]+x[1]*x[1]); lv = std::sqrt(rmsC); }
                else lv = std::max(std::fabs(x[0]), std::fabs(x[1]));
                double o = l2dB(lv) - p[C_THR], k = std::max(0.01f, p[C_KNEE]), t, slope = 1 - 1.0/p[C_RATIO];
                if (2*o < -k) t = 0; else if (2*std::fabs(o) <= k) t = slope * (o + k/2) * (o + k/2) / (2*k); else t = slope * o;
                cGR = t > cGR ? ca*cGR + (1-ca)*t : cr*cGR + (1-cr)*t;
                double g = dB2l(-cGR + p[C_MAKEUP]); x[0] *= g; x[1] *= g;
            }
            if (p[RL_ON] > .5) {
                rlMs = rw*rlMs + (1-rw)*0.5*(x[0]*x[0]+x[1]*x[1]);
                double over = 10*std::log10(std::max(rlMs, 1e-14)) - p[RL_THR];
                double t = over > 0 ? over * (1 - 1.0/p[RL_RATIO]) : 0;
                rlGR = t > rlGR ? ra*rlGR + (1-ra)*t : rr*rlGR + (1-rr)*t;
                double g = dB2l(-rlGR); x[0] *= g; x[1] *= g;
            }
            // ---- Translation engine ----
            if (lPre.push(x[0], x[1])) trT = (p[TR_LOUD] > .5 && lPre.S > -60) ? dB2l(std::clamp(p[TR_TGT] - lPre.S, -6.0, 6.0)) : 1.0;
            trG += (trT - trG) * trA;
            if (p[TR_PROF] > .5 && p[TR_AMT] > 0) { int pi = std::clamp((int)p[TR_PROF], 0, 6);
                for (int c = 0; c < 2; c++) for (int j = 0; j < 3; j++) if (PROF[pi][j].t) x[c] = tr[c][j].p(x[c]); }
            if (p[TR_BASS] > 0.001) {   // psychoacoustic bass: generate upper harmonics of <120 Hz content for small speakers
                double u = bl.p(0.5 * (x[0] + x[1])), hh = bh2.p(bh1.p(std::tanh(4 * u))), add = p[TR_BASS] * 0.5 * hh;
                x[0] += add; x[1] += add;
            }
            x[0] *= trG; x[1] *= trG;
            if (p[TP_ON] > .5) {
                int n = la + 4;
                for (int c = 0; c < 2; c++) dl[c][w] = x[c];
                double peak = 0;
                for (int c = 0; c < 2; c++) { double s[4]; for (int j = 0; j < 4; j++) s[j] = dl[c][(w - 3 + j + n) % n]; peak = std::max(peak, isp(s)); }
                tg[w] = peak > ceil ? ceil / peak : 1.0;
                double mn = 1.0; for (int j = 0; j < la; j++) mn = std::min(mn, tg[(w - j + n) % n]);
                gSm = mn < gSm ? mn : tr_ * gSm + (1 - tr_) * mn; gs[w] = std::min(gSm, mn);
                double avg = 0; for (int j = 0; j < la; j++) avg += gs[(w - j + n) % n]; avg /= la;
                for (int c = 0; c < 2; c++) x[c] = dl[c][(w - la + 2 + n) % n] * std::min(avg, gs[w]);
                w = (w + 1) % n;
            }
            io[2*i] = (float)x[0]; io[2*i+1] = (float)x[1];
            if (lOut.push(x[0], x[1])) { mv[3] = (float)lOut.M; mv[4] = (float)lOut.S; mv[5] = (float)lOut.I; }
            cLR += cA * (x[0]*x[1] - cLR); cLL += cA * (x[0]*x[0] - cLL); cRR += cA * (x[1]*x[1] - cRR);
            ar[ap] = 0.5 * (x[0] + x[1]); ap = (ap + 1) & 65535;
            if ((i & 7) == 0) { sc[sp] = (float)x[0]; sc[sp+1] = (float)x[1]; sp = (sp + 2) % 512; }
            pk = std::max(pk, std::max(std::fabs(x[0]), std::fabs(x[1]))); sq += 0.5*(x[0]*x[0]+x[1]*x[1]);
            gr = std::max(gr, cGR + rlGR);
        }
        mv[0] = (float)l2dB(pk); mv[1] = (float)(10*std::log10(std::max(sq/std::max(frames,1), 1e-12))); mv[2] = (float)gr;
        mv[6] = (float)(cLR / std::sqrt(cLL * cRR + 1e-20));
    }
    // 96 log-spaced spectrum bins (dBFS) + [fundamental Hz, H2 dB rel, H3 dB rel]; FFT size 4096..65536
    void analyze(float* out) {
        int n = 1 << (int)std::clamp(p[FFT_LOG], 12.f, 16.f); if (afft.n != n) { afft.init(n); ab.assign(n, 0); }
        for (int i = 0; i < n; i++) ab[i] = ar[(ap - n + i) & 65535] * (0.5 - 0.5 * std::cos(2*M_PI*i/(n-1)));
        afft.run(ab.data(), false);
        std::vector<double> mg(n / 2); for (int k = 0; k < n/2; k++) mg[k] = std::abs(ab[k]) / (n / 4.0);
        double fmax = std::min(20000.0, fs * 0.49);
        for (int i = 0; i < 96; i++) {
            double f0 = 20 * std::pow(fmax / 20, i / 96.0), f1 = 20 * std::pow(fmax / 20, (i + 1) / 96.0);
            int k0 = std::max(1, (int)(f0 * n / fs)), k1 = std::min(n/2 - 1, std::max(k0, (int)(f1 * n / fs))); double m = 0;
            for (int k = k0; k <= k1; k++) m = std::max(m, mg[k]);
            out[i] = (float)l2dB(std::max(m, 1e-7));
        }
        int ka = std::max(2, (int)(40.0 * n / fs)), kb = std::min(n/6 - 3, (int)(6000.0 * n / fs)), km = ka;
        for (int k = ka; k <= kb; k++) if (mg[k] > mg[km]) km = k;
        out[96] = 0; out[97] = out[98] = -120;
        if (l2dB(mg[km]) > -60 && 3*km + 2 < n/2) {
            auto band = [&](int c) { double m = 0; for (int k = c - 2; k <= c + 2; k++) m = std::max(m, mg[k]); return m; };
            out[96] = (float)(km * fs / n); out[97] = (float)l2dB(band(2*km) / mg[km]); out[98] = (float)l2dB(band(3*km) / mg[km]);
        }
    }
    void scope(float* out) { for (int i = 0; i < 512; i++) out[i] = sc[(sp + i) % 512]; }
};

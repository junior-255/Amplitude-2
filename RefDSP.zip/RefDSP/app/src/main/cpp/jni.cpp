#include <jni.h>
#include "engine.h"
static Engine E;
extern "C" {
JNIEXPORT void JNICALL Java_com_refdsp_Native_init(JNIEnv*, jobject, jint sr) { E.init(sr); }
JNIEXPORT void JNICALL Java_com_refdsp_Native_setParam(JNIEnv*, jobject, jint id, jfloat v) { if (id >= 0 && id < NP) E.p[id] = v; }
JNIEXPORT void JNICALL Java_com_refdsp_Native_process(JNIEnv* env, jobject, jfloatArray a, jint frames) {
    jfloat* d = (jfloat*)env->GetPrimitiveArrayCritical(a, nullptr); if (!d) return; E.process(d, frames); env->ReleasePrimitiveArrayCritical(a, d, 0); }
JNIEXPORT jfloatArray JNICALL Java_com_refdsp_Native_meters(JNIEnv* env, jobject) {
    jfloatArray r = env->NewFloatArray(8); float m[8]; for (int i = 0; i < 8; i++) m[i] = E.mv[i]; env->SetFloatArrayRegion(r, 0, 8, m); return r; }
JNIEXPORT jfloatArray JNICALL Java_com_refdsp_Native_analyze(JNIEnv* env, jobject) {
    float o[99]; E.analyze(o); jfloatArray r = env->NewFloatArray(99); env->SetFloatArrayRegion(r, 0, 99, o); return r; }
JNIEXPORT jfloatArray JNICALL Java_com_refdsp_Native_scope(JNIEnv* env, jobject) {
    float o[512]; E.scope(o); jfloatArray r = env->NewFloatArray(512); env->SetFloatArrayRegion(r, 0, 512, o); return r; }
JNIEXPORT void JNICALL Java_com_refdsp_Native_setIR(JNIEnv* env, jobject, jfloatArray a, jint n) {
    jfloat* d = env->GetFloatArrayElements(a, nullptr); E.setIR(d, n); env->ReleaseFloatArrayElements(a, d, JNI_ABORT); }
JNIEXPORT jint JNICALL Java_com_refdsp_Native_latency(JNIEnv*, jobject) { return E.latency(); }
JNIEXPORT void JNICALL Java_com_refdsp_Native_resetLufs(JNIEnv*, jobject) { E.lufsReset = 1; }
}

package com.refdsp

import android.content.Context
import android.graphics.*
import android.view.View

/** Spectrum (top), scrolling spectrogram (middle), phase scope / Lissajous (bottom). */
class AnalysisView(c: Context) : View(c) {
    private val bins = FloatArray(99) { -120f }
    private var sc = FloatArray(512)
    private val bmp = Bitmap.createBitmap(160, 96, Bitmap.Config.ARGB_8888)
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    fun update(b: FloatArray, s: FloatArray) {
        System.arraycopy(b, 0, bins, 0, 99); sc = s
        val px = IntArray(160 * 96); bmp.getPixels(px, 0, 160, 0, 0, 160, 96)
        for (y in 0 until 96) { System.arraycopy(px, y * 160 + 1, px, y * 160, 159); px[y * 160 + 159] = color(bins[95 - y]) }
        bmp.setPixels(px, 0, 160, 0, 0, 160, 96); invalidate()
    }
    private fun color(db: Float): Int {
        val t = ((db + 100f) / 100f).coerceIn(0f, 1f)
        return Color.HSVToColor(floatArrayOf(240f - 240f * t, 1f, maxOf(t, 0.15f)))
    }
    override fun onMeasure(w: Int, h: Int) = setMeasuredDimension(MeasureSpec.getSize(w), (420 * resources.displayMetrics.density).toInt())
    override fun onDraw(cv: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        cv.drawColor(Color.BLACK)
        paint.style = Paint.Style.STROKE; paint.strokeWidth = 3f; paint.color = Color.GREEN
        val path = Path(); val sh = h * 0.38f
        for (i in 0 until 96) { val x = i * w / 95f; val y = sh * (1f - ((bins[i] + 100f) / 100f).coerceIn(0f, 1f)); if (i == 0) path.moveTo(x, y) else path.lineTo(x, y) }
        cv.drawPath(path, paint)
        cv.drawBitmap(bmp, null, RectF(0f, h * 0.40f, w, h * 0.68f), paint)
        val cx = w / 2; val cy = h * 0.84f; val r = h * 0.14f
        paint.strokeWidth = 1f; paint.color = Color.DKGRAY; cv.drawRect(cx - r, cy - r, cx + r, cy + r, paint)
        paint.strokeWidth = 4f; paint.color = Color.CYAN
        for (i in 0 until 256) { val l = sc[2 * i]; val rr = sc[2 * i + 1]; cv.drawPoint(cx + (l - rr) * 0.7f * r, cy - (l + rr) * 0.7f * r, paint) }
    }
}

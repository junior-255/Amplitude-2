package com.refdsp
object Native {
    init { System.loadLibrary("refdsp") }
    external fun init(sr: Int)
    external fun setParam(id: Int, v: Float)
    external fun process(buf: FloatArray, frames: Int)
    external fun meters(): FloatArray   // peak, rms, GR, LUFS-M, LUFS-S, LUFS-I, correlation
    external fun analyze(): FloatArray  // 96 spectrum bins (dBFS) + fundamental Hz, H2 dB, H3 dB
    external fun scope(): FloatArray    // 256 L/R pairs
    external fun setIR(ir: FloatArray, n: Int)
    external fun latency(): Int
    external fun resetLufs()
}

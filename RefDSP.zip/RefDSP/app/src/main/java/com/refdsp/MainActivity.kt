package com.refdsp

import android.app.Activity
import android.content.Intent
import android.media.*
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.*
import java.nio.ByteBuffer
import java.nio.ByteOrder

class MainActivity : Activity() {
    private var pcm: FloatArray? = null
    private var rate = 48000
    @Volatile private var playing = false
    private lateinit var meter: TextView
    private lateinit var view: AnalysisView
    private val ui = Handler(Looper.getMainLooper())
    private val EQ0 = 36
    private val bandTypes = listOf("Off", "Peak", "Low shelf", "High shelf", "High-pass", "Low-pass", "Notch")
    // per band: type, freq, gain, Q, analog-sat
    private val band = Array(8) { b -> floatArrayOf(
        intArrayOf(2, 1, 1, 1, 1, 1, 1, 3)[b].toFloat(),
        floatArrayOf(50f, 150f, 400f, 1000f, 2500f, 6000f, 10000f, 14000f)[b], 0f, if (b == 0 || b == 7) .7f else 1f, .5f) }
    private var cur = 0

    private fun addSlider(root: LinearLayout, name: String, lo: Float, hi: Float, def: Float, st: Float, log: Boolean = false, cb: (Float) -> Unit): (Float) -> Unit {
        val tv = TextView(this); val sb = SeekBar(this)
        fun toV(p: Int) = if (log) (lo * Math.pow((hi / lo).toDouble(), p / 1000.0)).toFloat() else lo + p * st
        fun toP(v: Float) = if (log) (1000 * Math.log((v / lo).toDouble()) / Math.log((hi / lo).toDouble())).toInt() else ((v - lo) / st).toInt()
        sb.max = if (log) 1000 else ((hi - lo) / st).toInt(); sb.progress = toP(def); tv.text = "$name: ${"%.2f".format(def)}"
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(x: SeekBar?, p: Int, u: Boolean) { val v = toV(p); tv.text = "$name: ${"%.2f".format(v)}"; if (u) cb(v) }
            override fun onStartTrackingTouch(x: SeekBar?) {}
            override fun onStopTrackingTouch(x: SeekBar?) {} })
        root.addView(tv); root.addView(sb)
        return { v -> sb.progress = toP(v); tv.text = "$name: ${"%.2f".format(v)}" }
    }
    private fun header(root: LinearLayout, t: String) = root.addView(TextView(this).apply { text = t; textSize = 18f; setPadding(0, 40, 0, 8) })
    private fun spinner(root: LinearLayout, items: List<String>, sel: Int, cb: (Int) -> Unit): Spinner = Spinner(this).apply {
        adapter = ArrayAdapter(context, android.R.layout.simple_spinner_dropdown_item, items); setSelection(sel)
        onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) = cb(pos)
            override fun onNothingSelected(p: AdapterView<*>?) {} }
        root.addView(this) }
    private fun switch(root: LinearLayout, n: String, id: Int, on: Boolean) = root.addView(Switch(this).apply {
        text = n; isChecked = on; setOnCheckedChangeListener { _, c -> Native.setParam(id, if (c) 1f else 0f) } })
    private fun p(id: Int) = { v: Float -> Native.setParam(id, v) }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 48, 32, 32) }
        view = AnalysisView(this); root.addView(view)
        meter = TextView(this).apply { text = "--"; typeface = android.graphics.Typeface.MONOSPACE; textSize = 12f }
        root.addView(meter)
        root.addView(Button(this).apply { text = "Load WAV (16-bit PCM)"; setOnClickListener { pick(1) } })
        root.addView(Button(this).apply { text = "Load impulse response (FIR convolution)"; setOnClickListener { pick(2) } })
        root.addView(Button(this).apply { text = "Play / Stop"; setOnClickListener { toggle() } })
        root.addView(Button(this).apply { text = "Reset LUFS"; setOnClickListener { Native.resetLufs() } })
        header(root, "Analyzer")
        spinner(root, listOf("FFT 4096", "FFT 8192", "FFT 16384", "FFT 32768", "FFT 65536 (0.73 Hz)"), 1) { Native.setParam(32, (12 + it).toFloat()) }

        header(root, "Parametric EQ (analog)")
        switch(root, "Parametric EQ", 24, true); switch(root, "Linear-phase (adds ~64 ms latency)", 25, false)
        addSlider(root, "Analog saturation amount", 0f, 1f, .5f, .01f, cb = p(26))
        val bs = spinner(root, (1..8).map { "Band $it" }, 0) { cur = it; refreshBand() }
        val ts = spinner(root, bandTypes, band[0][0].toInt()) { band[cur][0] = it.toFloat(); Native.setParam(EQ0 + cur * 5, it.toFloat()) }
        val sF = addSlider(root, "Freq Hz", 20f, 20000f, 50f, 0f, true) { band[cur][1] = it; Native.setParam(EQ0 + cur * 5 + 1, it) }
        val sG = addSlider(root, "Gain dB", -18f, 18f, 0f, .1f) { band[cur][2] = it; Native.setParam(EQ0 + cur * 5 + 2, it) }
        val sQ = addSlider(root, "Q", .1f, 50f, .7f, 0f, true) { band[cur][3] = it; Native.setParam(EQ0 + cur * 5 + 3, it) }
        val sS = addSlider(root, "Band analog saturation", 0f, 1f, .5f, .01f) { band[cur][4] = it; Native.setParam(EQ0 + cur * 5 + 4, it) }
        refreshBand = { ts.setSelection(band[cur][0].toInt()); sF(band[cur][1]); sG(band[cur][2]); sQ(band[cur][3]); sS(band[cur][4]) }

        header(root, "Translation engine")
        spinner(root, listOf("Off", "Studio Monitors", "Headphones", "IEM", "Bluetooth Speaker", "Car Audio", "Consumer"), 0) { Native.setParam(27, it.toFloat()) }
        addSlider(root, "Profile amount", 0f, 1f, 1f, .01f, cb = p(28)); addSlider(root, "Bass translation (harmonics)", 0f, 1f, 0f, .01f, cb = p(29))
        switch(root, "Loudness consistency", 30, false); addSlider(root, "Target LUFS-S", -30f, -6f, -14f, .5f, cb = p(31))
        switch(root, "IR convolution", 33, false)

        header(root, "Dynamics")
        for ((n, id, d) in listOf(Triple("Saturation", 0, true), Triple("Compressor", 7, true), Triple("RMS Limiter", 15, true), Triple("True Peak Limiter", 21, true))) switch(root, n, id, d)
        spinner(root, listOf("Tape", "Analog Console", "Tube", "Even Harmonics", "Odd Harmonics", "Hybrid"), 3) { Native.setParam(1, it.toFloat()) }
        data class S(val n: String, val id: Int, val lo: Float, val hi: Float, val d: Float, val st: Float = .1f)
        for (s in listOf(S("Sat Drive dB", 2, 0f, 24f, 6f), S("Sat Mix", 3, 0f, 1f, 1f, .01f), S("Harmonic Intensity", 4, 0f, 1f, .5f, .01f),
            S("Sat Trim dB", 5, -12f, 12f, 0f), S("Oversampling (2^n)", 6, 0f, 4f, 2f, 1f),
            S("Comp Thr dB", 8, -60f, 0f, -18f), S("Comp Ratio", 9, 1f, 20f, 2.5f), S("Comp Atk ms", 10, .1f, 100f, 10f),
            S("Comp Rel ms", 11, 10f, 1000f, 120f, 1f), S("Comp Knee dB", 12, 0f, 24f, 6f), S("Comp Makeup dB", 13, 0f, 24f, 0f),
            S("RMS Lim Thr dB", 16, -40f, 0f, -14f), S("RMS Lim Ratio", 17, 1f, 20f, 8f), S("RMS Window ms", 18, 5f, 1000f, 300f, 1f),
            S("RMS Lim Atk ms", 19, 1f, 200f, 20f), S("RMS Lim Rel ms", 20, 10f, 2000f, 300f, 1f),
            S("TP Ceiling dBTP", 22, -6f, 0f, -1f), S("TP Release ms", 23, 10f, 1000f, 150f, 1f)))
            addSlider(root, s.n, s.lo, s.hi, s.d, s.st, cb = p(s.id))
        setContentView(ScrollView(this).apply { addView(root) })
        Native.init(rate)
    }
    private var refreshBand: () -> Unit = {}

    private fun pick(code: Int) = startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply { type = "audio/*"; addCategory(Intent.CATEGORY_OPENABLE) }, code)

    private fun readWav(uri: Uri): Pair<FloatArray, Int>? {
        val bytes = contentResolver.openInputStream(uri)!!.use { it.readBytes() }
        val bb = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
        var pos = 12; var ch = 2; var sr = 48000
        while (pos + 8 <= bytes.size) {
            val id = String(bytes, pos, 4); val len = bb.getInt(pos + 4)
            if (id == "fmt ") { ch = bb.getShort(pos + 10).toInt(); sr = bb.getInt(pos + 12) }
            if (id == "data") {
                val n = minOf(len, bytes.size - pos - 8) / 2; val a = FloatArray(n)
                for (i in 0 until n) a[i] = bb.getShort(pos + 8 + 2 * i) / 32768f
                return Pair(if (ch == 2) a else FloatArray(n * 2) { a[it / 2] }, sr)
            }
            pos += 8 + len + (len and 1)
        }
        return null
    }

    override fun onActivityResult(rq: Int, rs: Int, d: Intent?) {
        val uri = d?.data ?: return
        val (a, sr) = readWav(uri) ?: return Toast.makeText(this, "Unsupported WAV (need 16-bit PCM)", Toast.LENGTH_LONG).show()
        if (rq == 1) { playing = false; Thread.sleep(80); pcm = a; rate = sr; Native.init(rate); refreshAll(); Toast.makeText(this, "Loaded @ $sr Hz", Toast.LENGTH_SHORT).show() }
        else {
            val n = minOf(a.size / 2, 16384); val ir = FloatArray(n) { a[2 * it] }; Native.setIR(ir, n)
            Toast.makeText(this, if (sr != rate) "IR rate $sr != $rate Hz (no resampling)" else "IR loaded ($n taps)", Toast.LENGTH_LONG).show()
        }
    }
    private fun refreshAll() { // Native.init keeps params; nothing to resend
    }

    private fun toggle() {
        if (playing) { playing = false; return }
        val data = pcm ?: return; playing = true
        Thread {
            val min = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_FLOAT)
            val at = AudioTrack.Builder()
                .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).build())
                .setAudioFormat(AudioFormat.Builder().setSampleRate(rate).setEncoding(AudioFormat.ENCODING_PCM_FLOAT).setChannelMask(AudioFormat.CHANNEL_OUT_STEREO).build())
                .setBufferSizeInBytes(maxOf(min, 32768)).setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY).build()
            at.play(); val blk = FloatArray(2048); var i = 0; var k = 0
            while (playing && i + 2 <= data.size) {
                val n = minOf(blk.size, data.size - i) and 1.inv(); java.util.Arrays.fill(blk, 0f); System.arraycopy(data, i, blk, 0, n)
                Native.process(blk, 1024); at.write(blk, 0, 2048, AudioTrack.WRITE_BLOCKING); i += n
                if (++k % 3 == 0) {
                    val m = Native.meters(); val a = Native.analyze(); val s = Native.scope(); val lat = Native.latency() * 1000 / rate
                    val txt = "Peak %.1f dBFS  RMS %.1f  Crest %.1f dB\nLUFS M %.1f  S %.1f  I %.1f\nGR %.1f dB  Corr %.2f  Latency %d ms\nFund %.0f Hz  H2 %.1f dB  H3 %.1f dB".format(
                        m[0], m[1], m[0] - m[1], m[3], m[4], m[5], m[2], m[6], lat, a[96], a[97], a[98])
                    ui.post { view.update(a, s); meter.text = txt }
                }
            }
            at.stop(); at.release(); playing = false
        }.start()
    }
}
